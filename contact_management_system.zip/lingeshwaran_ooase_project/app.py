from flask import Flask, render_template, request, redirect, url_for, flash
import mysql.connector

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Database connection
def get_db_connection():
    return mysql.connector.connect(
        host='localhost',
        user='root',
        password='Kiruthika0104!',  # Update with your MySQL password
        database='contact_management'
    )

# Home Page
@app.route('/')
def home():
    return render_template('home.html', body_class="home")


# View Contacts
@app.route('/view')
def view_contacts():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM contacts")
    contacts = cursor.fetchall()
    conn.close()
    return render_template('view.html', contacts=contacts)

# Add Contact
@app.route('/add', methods=['GET', 'POST'])
def add_contact():
    if request.method == 'POST':
        name = request.form['name']
        phone = request.form['phone']
        email = request.form['email']
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO contacts (name, phone, email) VALUES (%s, %s, %s)", (name, phone, email))
        conn.commit()
        conn.close()
        flash("Contact added successfully!", "success")
        return redirect(url_for('view_contacts'))
    return render_template('add.html')

# Update Contact
@app.route('/update/<int:id>', methods=['GET', 'POST'])
def update_contact(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    if request.method == 'POST':
        name = request.form['name']
        phone = request.form['phone']
        email = request.form['email']
        cursor.execute("UPDATE contacts SET name=%s, phone=%s, email=%s WHERE id=%s", (name, phone, email, id))
        conn.commit()
        conn.close()
        flash("Contact updated successfully!", "success")
        return redirect(url_for('view_contacts'))
    cursor.execute("SELECT * FROM contacts WHERE id=%s", (id,))
    contact = cursor.fetchone()
    conn.close()
    return render_template('update.html', contact=contact)

# Delete Contact Confirmation Page
@app.route('/delete/<int:id>', methods=['GET', 'POST'])
def delete_contact(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    if request.method == 'POST':
        cursor.execute("DELETE FROM contacts WHERE id=%s", (id,))
        conn.commit()
        conn.close()
        flash("Contact deleted successfully!", "success")
        return redirect(url_for('view_contacts'))
    cursor.execute("SELECT * FROM contacts WHERE id=%s", (id,))
    contact = cursor.fetchone()
    conn.close()
    return render_template('delete.html', contact=contact)

# Search Contacts
@app.route('/search', methods=['POST'])
def search_contacts():
    search_term = request.form['search']
    conn = get_db_connection()
    cursor = conn.cursor()
    query = "SELECT * FROM contacts WHERE name LIKE %s OR phone LIKE %s OR email LIKE %s"
    cursor.execute(query, (f'%{search_term}%', f'%{search_term}%', f'%{search_term}%'))
    contacts = cursor.fetchall()
    conn.close()
    return render_template('view.html', contacts=contacts)

if __name__ == '__main__':
    app.run(debug=True)
